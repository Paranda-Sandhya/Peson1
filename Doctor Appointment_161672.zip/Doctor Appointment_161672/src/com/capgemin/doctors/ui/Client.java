
package com.capgemin.doctors.ui;


import java.time.LocalDate;
import java.util.Scanner;

import com.capgemin.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.service.DoctorAppointmentserviceimp;



public class Client {

	public static void main(String[] args) {
		int appointmentId; String patientName=null;String phoneNumber=null; String email=null;String gender=null;
			LocalDate appointmentDate; int age; String problemName;
		String doctorName;String appointmentStatus;
 	   DoctorAppointmentserviceimp service= new DoctorAppointmentserviceimp();
     DoctorAppointment bean=new DoctorAppointment();
     while(true)
          {
         System.out.println("----Welcome to Apollo Hospital----");
         System.out.println("1.Book Doctor Appointment");
         System.out.println("2.view Doctor Appointment");
         System.out.println("3.Exit");
         
         
        
         Scanner sc = new Scanner(System.in);

         int choice = sc.nextInt();
         switch (choice){

        	 case 1:  
        		 
			do{
                      System.out.println("enter  your Name");
                   String patientName1 = sc.next();
            } while(service.validatepatientname(patientName));
               
		        
		        do{     
		               System.out.println("enter your phone number");
		               String phoneNumber1= sc.next();;
		              
		             } while(service.validatephoneNumber(phoneNumber));

	            do{
	              System.out.println("enter your Email id");
	              String email1 = sc.next();
	              }while(service.validateemailId(email));
	            
	           
	                System.out.println("enter your Age");
	                age = sc.nextInt();
	             
	           System.out.println("enter problemName");
               problemName=sc.next();
           
                   
          
    System.out.println("Select your Gender[1.Male 2.Female 3.Other");
               gender= sc.next();
            
           
             
              bean.setPatientName(patientName);
              bean.setPhoneNumber(phoneNumber);
              bean.setEmail(email);
              bean.setAge(age);
              bean.setGender(gender);
              bean.setProblemName(problemName);
            
              int appointmentId1=(int)(Math.random()*10000);
              bean.setAppointmentId(appointmentId1);
              boolean isAdded=service.addDoctorAppointmentDetails(bean);
               if(isAdded)
               {
              
               System.out.println(" Appointment has successfully successfully and APPROVED");
              System.out.println("Your appointmentId is:");
               bean.setAppointmentId(appointmentId1);
               System.out.println(bean);
               
                }
           else
               System.out.println(" SORRY your appointment has been DISAPPROVED");
   
           break;
       	 case 2:
      		 System.out.println("Enter your appointmentId");
                 int appointmentId2=sc.nextInt();
		DoctorAppointment a=service.getDoctorAppointmentDetails(appointmentId2);
			System.out.println(a);
          
               break;
        	 case 3 :
        		 System.out.println("Thankyou ");
        		 System.exit(0);
 				break;
 			default:
 				System.err.println("Invalid Option Choose from 1 to 7");
 				System.out.println();
 				break;
}
          }
	}
}
