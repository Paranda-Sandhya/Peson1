package com.capgemini.doctors.service;

import com.capgemin.doctors.bean.DoctorAppointment;

public interface IDoctorAppointmentService {
   public boolean addDoctorAppointmentDetails(DoctorAppointment  bean);
  public DoctorAppointment getDoctorAppointmentDetails(int appointmentId);
  
}
