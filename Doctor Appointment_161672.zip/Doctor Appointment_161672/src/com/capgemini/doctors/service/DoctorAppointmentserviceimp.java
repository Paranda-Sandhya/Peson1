package com.capgemini.doctors.service;




import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemin.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDaoimp;

public class DoctorAppointmentserviceimp implements IDoctorAppointmentService {
	DoctorAppointmentDaoimp dao= new DoctorAppointmentDaoimp();
    
	@Override
	public boolean addDoctorAppointmentDetails(DoctorAppointment bean) {
		// TODO Auto-generated method stub
		return dao.addDoctorAppointmentDetails(bean);
	}

	@Override
	public DoctorAppointment getDoctorAppointmentDetails(int appointmentId) {
		
		return dao.getDoctorAppointmentDetails(appointmentId);
	}

	public boolean validatepatientname(String accName){
		boolean flag=true;
		Pattern pattern=Pattern.compile("[A-za-z]*");
		Matcher m = pattern.matcher(accName);
		if((m.matches()) && (accName.length()>2))
		{
		    flag=false;
		}
		return flag;
		}
	
		
	public boolean validateemailId(String email){
		boolean flag=true;
		Pattern pattern=Pattern.compile("[a-zA-Z0-9.]*@[a-zA-Z0-9]+([.][a-zA-z]+)");
		Matcher m = pattern.matcher(email);
		if(m.matches())
		{
		 flag=false;
		}
		return flag;
		}

	

public boolean validateAppointmentId(DoctorAppointment bean,long id)
{boolean flag=false;
if((bean.getAppointmentId()==id)){
        flag=true;
    }
    return flag;
            }

public boolean validatephoneNumber(String phoneNumber) {
	// TODO Auto-generated method stub
	boolean flag=true;
	Pattern pattern=Pattern.compile("[7-9][0-9]{9}");
	Matcher m = pattern.matcher(phoneNumber);
	if(m.matches())
	{
	 flag=false;
	}
	return flag;
	}
}



