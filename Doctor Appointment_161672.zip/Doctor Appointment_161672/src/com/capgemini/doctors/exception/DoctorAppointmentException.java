package com.capgemini.doctors.exception;

public class DoctorAppointmentException extends Exception
{
	public DoctorAppointmentException() {
		super();
	}

	public DoctorAppointmentException(String message) {
		super(message);
	}

}


