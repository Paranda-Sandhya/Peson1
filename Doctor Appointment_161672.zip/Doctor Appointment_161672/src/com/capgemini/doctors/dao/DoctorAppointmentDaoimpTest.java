package com.capgemini.doctors.dao;

import static org.junit.Assert.*;
import Customer;
import WalletException;

import org.junit.Test;

import com.capgemin.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DoctorAppointmentException;

public class DoctorAppointmentDaoimpTest extends DoctorAppointmentDaoimp {
dao=null;
	@Test
	public void testAddDoctorAppointmentDetails() {
		DoctorAppointment b=new DoctorAppointment();
		b.setPatientName("sujatha");
		b.setPhoneNumber("9951942754");
		
		b.setEmail("lavanya@mail.com");
		b.setAddress("Pune");
		
		try {
			Object c;
			dao.addDoctorAppointment(c);
			DoctorAppointment c1 = dao.getAppointmentId(1009);
			assertNotNull(c1);
		} catch (DoctorAppointmentException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testGetDoctorAppointmentDetails() {
		fail("Not yet implemented");
	}


}
