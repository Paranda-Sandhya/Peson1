package com.capgemini.doctors.dao;

import com.capgemin.doctors.bean.DoctorAppointment;

public interface IDoctorAppointmentDao {

	public boolean addDoctorAppointmentDetails(DoctorAppointment  bean);
	 public DoctorAppointment getDoctorAppointmentDetails(int appointmentId);
	  
}
 