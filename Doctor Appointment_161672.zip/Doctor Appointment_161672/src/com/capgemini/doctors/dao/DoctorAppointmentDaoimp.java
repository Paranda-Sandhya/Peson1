package com.capgemini.doctors.dao;

import java.util.HashMap;

import com.capgemin.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.service.IDoctorAppointmentService;

public class DoctorAppointmentDaoimp implements IDoctorAppointmentService {
	HashMap<Long,DoctorAppointment> patList = new HashMap<Long,DoctorAppointment>();
	@Override
	public boolean addDoctorAppointmentDetails(DoctorAppointment bean) {
		  int key=bean.getAppointmentId();
	        patList.put((long) key,bean);
	        return patList.containsValue(bean);
	}

	@Override
	public DoctorAppointment getDoctorAppointmentDetails(int appointmentId) {
		{
			
		        // TODO Auto-generated method stub
		        DoctorAppointment a = null;
		        for (DoctorAppointment a1 : patList.values()) {
		            if (a1.getAppointmentId() == appointmentId) {
		                a = a1;
		            }
		        }
		        return a;
		    }
}
}